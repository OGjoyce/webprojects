<?
header('Access-Control-Allow-Origin: *');
header('Access-Control-Request-Method: *');
header('Content-type: application/json');

 
?>