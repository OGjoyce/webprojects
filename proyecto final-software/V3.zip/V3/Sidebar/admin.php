<div class = "col-md-2 ">
  <div class="list-group">
  <a href="usuario.php" class="list-group-item">Usuario</a>
  <a href="tarjeta.php" class="list-group-item">Tarjeta</a>
  <a href="direccion.php" class="list-group-item">Direccion</a>
  <a href="telefono.php" class="list-group-item">Telefono</a>
  <a href="empresa.php" class="list-group-item">Empresa</a>
  <a href="producto.php" class="list-group-item">Producto</a>
  <a href="carrito.php" class="list-group-item">Carrito</a>
  <a href="tipo.php" class="list-group-item">tipo</a>
  <a href="transaccion.php" class="list-group-item">transaccion</a>
  <a href="busqueda.php" class="list-group-item">busqueda</a>
</div>
</div>
