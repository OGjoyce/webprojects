<link rel="stylesheet" href="misc/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="misc/bootstrap/css/font-awesome.min.css">
<link rel="stylesheet" href="misc/bootstrap/css/main.css">
<script type="text/javascript" src="misc/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="misc/bootstrap/js/bootstrap.min.js"></script>
<?php
session_start();
include 'function.php';
include 'Navbar/inicio.php'
?>
