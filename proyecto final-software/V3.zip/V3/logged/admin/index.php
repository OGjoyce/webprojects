<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Administrador</title>
    <?php include 'lib.php';?>
  </head>
  <body>
    <div class = "col-md-5 ">
      <p>
        Bienvenido a la pagina del administrador.
        Aqui podrá modificar todas las tablas del programa.
      </p>
    </div>
  </body>
</html>
